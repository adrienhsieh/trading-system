"""
trading/scanner.py — 股票掃描器（純淨相容版）
從 TWSE（上市）+ TPEX（上櫃）API 取得全台股票清單，並以技術指標篩選強勢股。
"""
import concurrent.futures
from typing import Optional
import requests
import urllib3
from trading.logger import get_logger

logger = get_logger("scanner")

# 抑制 SSL 憑證警告
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

from trading.constants import SCAN_WORKERS, REQUEST_TIMEOUT
from trading.indicators import IndicatorEngine
from trading.strategies import get_strategy


class StockScanner:
    """台股技術面掃描器，無鎖快取、標準連線機制。"""

    # 回歸最原始、不帶任何多餘字元的標準 API 網址
    TWSE_API_URL: str = "https://openapi.twse.com.tw/v1/exchangeReport/STOCK_DAY_ALL"
    TPEX_API_URL: str = "https://www.tpex.org.tw/openapi/v1/tpex_mainboard_daily_close_quotes"
    TWSE_INDUSTRY_URL: str = "https://openapi.twse.com.tw/v1/opendata/t187ap03_L"

    TECH_INDUSTRY_KEYWORDS: frozenset = frozenset([
        "半導體", "電腦", "光電", "通訊", "電子", "資訊", "科技",
    ])

    def __init__(self, indicator_engine: IndicatorEngine = None):
        self.indicator_engine = indicator_engine or IndicatorEngine()
        # 移除執行緒鎖，改用最直接的基礎字典
        self._stock_cache = {}
        self._industry_cache = {}

    # ── 股票代號表 ─────────────────────────────────────────────

    def get_stock_map(self) -> dict:
        """最原始的獲取股票清單邏輯"""
        if self._stock_cache:
            return self._stock_cache

        stock_map = {}
        timeout_val = REQUEST_TIMEOUT if 'REQUEST_TIMEOUT' in globals() else 10

        # TWSE 上市
        try:
            r = requests.get(
                self.TWSE_API_URL, 
                headers={"Accept": "application/json"}, 
                timeout=timeout_val, 
                verify=False
            )
            for item in r.json():
                code = str(item.get("Code", "")).strip()
                name = str(item.get("Name", "")).strip()
                if code.isdigit() and len(code) == 4:
                    stock_map[code] = name or code
            logger.info("TWSE API 取得 %d 檔", len(stock_map))
        except Exception as e:
            logger.warning("TWSE API 失敗: %s", e)

        # TPEX 上櫃
        tpex_count = 0
        try:
            r = requests.get(
                self.TPEX_API_URL, 
                headers={"Accept": "application/json"}, 
                timeout=timeout_val, 
                verify=False
            )
            for item in r.json():
                code = str(item.get("SecuritiesCompanyCode", "")).strip()
                name = str(item.get("CompanyName", "")).strip()
                if code.isdigit() and len(code) == 4 and code not in stock_map:
                    stock_map[code] = name or code
                    tpex_count += 1
            logger.info("TPEX API 取得 %d 檔（上櫃主板）", tpex_count)
        except Exception as e:
            logger.warning("TPEX API 失敗: %s", e)

        self._stock_cache = stock_map
        return stock_map

    def get_all_tw_stocks(self) -> list:
        return list(self.get_stock_map().keys())

    def get_stock_name(self, code: str) -> str:
        return self.get_stock_map().get(code, code)

    # ── 產業別資料 ─────────────────────────────────────────────

    @staticmethod
    def _is_tech_by_code(code: str) -> bool:
        try:
            n = int(code)
        except ValueError:
            return False
        return (3000 <= n <= 3699 or 4900 <= n <= 4999 or 5200 <= n <= 5399 or 6200 <= n <= 6999)

    def _fetch_industry_map(self) -> dict:
        if self._industry_cache:
            return self._industry_cache

        result = {}
        timeout_val = REQUEST_TIMEOUT if 'REQUEST_TIMEOUT' in globals() else 10

        try:
            r = requests.get(
                self.TWSE_INDUSTRY_URL, 
                headers={"Accept": "application/json"}, 
                timeout=timeout_val, 
                verify=False
            )
            for item in r.json():
                code = str(item.get("公司代號", "")).strip()
                ind = str(item.get("產業別", "")).strip()
                if code and ind:
                    result[code] = ind
            logger.info("TWSE 產業別取得 %d 筆", len(result))
        except Exception as e:
            logger.warning("TWSE 產業別失敗: %s", e)

        for code in self.get_stock_map():
            if code not in result and self._is_tech_by_code(code):
                result[code] = "電子"

        self._industry_cache = result
        return result

    def get_tech_stock_map(self) -> dict:
        sm = self.get_stock_map()
        ind = self._fetch_industry_map()
        return {
            code: name for code, name in sm.items()
            if any(kw in ind.get(code, "") for kw in self.TECH_INDUSTRY_KEYWORDS)
        }

    # ── 個股分析（策略通用） ────────────────────────────────────

    def analyze_one(self, code: str, capital: float, risk_pct: float, strategy: str = "trend", name: str = "") -> Optional[dict]:
        code = str(code)
        strat = get_strategy(strategy)
        df = self.indicator_engine.fetch_ohlcv(code)
        if df is None or len(df) < strat.min_bars:
            return None
        try:
            ind = strat.compute(df, code=code)
            if ind is None:
                return None
            params = strat.calc_entry_params(ind, capital, risk_pct)
            return {
                "code": code,
                "name": name or self.get_stock_name(code),
                "score": ind["score"],
                "ind": ind,
                "params": params,
                "strategy": strategy,
            }
        except Exception as e:
            logger.debug("%s %s 失敗: %s", strategy.upper(), code, e)
            return None

    # ── 批次掃描（策略通用） ────────────────────────────────────

    def run_scan(self, candidates: list, capital: float, risk_pct: float = 2.0, strategy: str = "trend", max_workers: int = SCAN_WORKERS) -> list:
        sm = self.get_stock_map()
        results = []
        with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as ex:
            futs = {
                ex.submit(self.analyze_one, c, capital, risk_pct, strategy, sm.get(c, "")): c
                for c in candidates
            }
            for f in concurrent.futures.as_completed(futs):
                r = f.result()
                if r:
                    results.append(r)
        results.sort(key=lambda x: x["score"], reverse=True)
        return results

    # ── API 格式化 ────────────────────────────────────────────

    def format_for_api(self, results: list, strategy: str = "trend") -> list:
        strat = get_strategy(strategy)
        labels = strat.signal_labels
        out = []
        for r in results:
            ind, params = r["ind"], r["params"]
            enabled_map = ind.get("enabled", {})
            item = {
                "code": r["code"],
                "name": r.get("name", ""),
                "score": r["score"],
                "total_enabled": ind.get("total_enabled", len(ind["signals"])),
                "strategy": r.get("strategy", strategy),
                "close": ind["close"],
                "signals": {
                    k: {
                        "pass": ind["signals"][k],
                        "label": labels.get(k, k),
                        "enabled": enabled_map.get(k, True),
                    } for k in ind["signals"]
                },
                "entry": params["entry"],
                "stop": params["stop"],
                "target": params["target"],
                "shares": params["shares"],
                "total_risk": params["total_risk"],
            }
            if strategy == "trend":
                item.update({
                    "ema5": ind.get("ema5"), "ema20": ind.get("ema20"), "ema60": ind.get("ema60"),
                    "adx": ind.get("adx"), "atr": ind.get("atr"), "macd_hist": ind.get("macd_hist"),
                    "w52_high": ind.get("w52_high"), "w52_low": ind.get("w52_low"),
                })
            elif strategy == "ict":
                item.update({
                    "equilibrium": ind.get("equilibrium"), "range_high": ind.get("range_high"),
                    "range_low": ind.get("range_low"), "ob_high": ind.get("ob_high"),
                    "ob_low": ind.get("ob_low"), "mss_level": ind.get("mss_level"),
                })
            elif strategy == "fundamental":
                item.update({
                    "pe": ind.get("pe"), "eps": ind.get("eps"), "forward_eps": ind.get("forward_eps"),
                    "pb": ind.get("pb"), "revenue_growth": ind.get("revenue_growth"),
                })
            out.append(item)
        return out

    # ── 向下相容 wrapper ───────────────────────────────────────

    def analyze_one_ict(self, code, capital, risk_pct, name=""):
        return self.analyze_one(code, capital, risk_pct, strategy="ict", name=name)

    def run_scan_ict(self, candidates, capital, risk_pct=2.0, max_workers=SCAN_WORKERS):
        return self.run_scan(candidates, capital, risk_pct, strategy="ict", max_workers=max_workers)