# -*- coding: utf-8 -*-
"""
trading/api/watchlist.py — 觀察名單 API (自適應多因子三位一體版本)
"""
import time
import pandas as pd
import requests
from defusedxml.ElementTree import fromstring
from flask import Blueprint, jsonify, request

from trading.api.auth import require_auth
from trading.services.container import container
from trading.logger import get_logger

logger = get_logger("watchlist_api")
watchlist_bp = Blueprint("watchlist", __name__)


@watchlist_bp.route("/api/watchlist")
@require_auth
def list_watchlist():
    items = container.pos_mgr.watchlist_list()
    return jsonify({"ok": True, "items": items})


@watchlist_bp.route("/api/watchlist", methods=["POST"])
@require_auth
def add_watchlist():
    data = request.get_json(silent=True) or {}
    code = str(data.get("code", "")).strip()
    if not code:
        return jsonify({"ok": False, "error": "缺少 code"}), 400
    name = container.scanner.get_stock_name(code)
    ok = container.pos_mgr.watchlist_add(code, name)
    if not ok:
        return jsonify({"ok": False, "error": f"{code} 已在觀察名單中"}), 409
    return jsonify({"ok": True, "code": code, "name": name})


@watchlist_bp.route("/api/watchlist/<code>", methods=["DELETE"])
@require_auth
def remove_watchlist(code: str):
    ok = container.pos_mgr.watchlist_remove(code)
    if not ok:
        return jsonify({"ok": False, "error": f"{code} 不在觀察名單中"}), 404
    return jsonify({"ok": True})


@watchlist_bp.route("/api/watchlist/analyze")
@require_auth
def analyze_watchlist():
    items = container.pos_mgr.watchlist_list()
    if not items:
        return jsonify({"ok": True, "results": []})

    cfg = container.config_mgr.load()
    capital = cfg.get("total_capital", 3000000)
    risk_pct = 1.0 if cfg.get("consecutive_losses", 0) >= 3 else 2.0

    results = []
    for item in items:
        code, name = item["code"], item["name"]
        result = {"code": code, "name": name}

        # 1. 趨勢策略分析
        trend = container.scanner.analyze_one(code, capital, risk_pct, strategy="trend")
        if trend:
            fmt = container.scanner.format_for_api([trend], strategy="trend")
            if fmt:
                f0 = fmt[0]
                sigs = f0.get("signals", {})
                passed = sum(1 for s in sigs.values() if s.get("pass"))
                result["trend"] = {
                    "score": passed, "total": len(sigs), "signals": sigs,
                    "close": f0.get("close"), "adx": f0.get("adx"),
                    "macd_hist": f0.get("macd_hist"), "atr": f0.get("atr"),
                    "ema5": f0.get("ema5"), "ema20": f0.get("ema20"), "ema60": f0.get("ema60"),
                    "volume": f0.get("volume"), "vol_avg": f0.get("vol_avg"),
                }
        if "trend" not in result:
            result["trend"] = None

        # 2. 基本面策略分析
        fund = container.scanner.analyze_one(code, capital, risk_pct, strategy="fundamental")
        if fund:
            fmt = container.scanner.format_for_api([fund], strategy="fundamental")
            if fmt:
                f0 = fmt[0]
                sigs = f0.get("signals", {})
                passed = sum(1 for s in sigs.values() if s.get("pass"))
                result["fundamental"] = {
                    "score": passed, "total": len(sigs), "signals": sigs,
                    "pe": f0.get("pe"), "eps": f0.get("eps"),
                    "forward_eps": f0.get("forward_eps"),
                    "pb": f0.get("pb"), "revenue_growth": f0.get("revenue_growth"),
                }
        if "fundamental" not in result:
            result["fundamental"] = None

        # 3. Google News 爬取
        result["news"] = _fetch_google_news(name or code, limit=5)

        # ── 🟢 串接 predict_svc 多因子權重引擎 ──
        predict_bull_pct = 50  # 預設中性
        predict_open_val = None
        
        if hasattr(container, "predict_svc") and result["trend"]:
            try:
                # 調用 yfinance 拉取歷史數據以供預測引擎運算 (含上市/上櫃智慧字尾防禦)
                import yfinance as yf
                if not code.endswith(('.TW', '.TWO')):
                    if code.isdigit() and int(code) >= 5000:
                        formatted_sym = f"{code}.TWO"
                    else:
                        formatted_sym = f"{code}.TW"
                else:
                    formatted_sym = code
                    
                raw_df = yf.download(formatted_sym, period="60d", progress=False)
                
                if not raw_df.empty:
                    df_kline = raw_df.copy()
                    if isinstance(df_kline.columns, pd.MultiIndex):
                        df_kline.columns = df_kline.columns.get_level_values(0)
                    df_kline.columns = [str(c).capitalize() for c in df_kline.columns]
                    
                    # 補算核心預測指標
                    df_kline['MA5'] = df_kline['Close'].rolling(window=5).mean()
                    df_kline['MA20'] = df_kline['Close'].rolling(window=20).mean()
                    
                    # 丟入單例容器中的預測核心精算
                    pred_res = container.predict_svc.calculate_prediction(df_kline, pd.DataFrame())
                    predict_bull_pct = pred_res.get("bull_percentage", 50)
                    predict_open_val = pred_res.get("predicted_open", None)
            except Exception as ex:
                logger.warning(f"觀察名單預測核心計算跳過 ({code}): {ex}")

        # ── 🟢 自適應 AI 權重綜合評分演算法 ──
        if result.get("trend") and result.get("fundamental"):
            t_score = result["trend"]["score"] / result["trend"]["total"] if result["trend"]["total"] > 0 else 0.5
            f_score = result["fundamental"]["score"] / result["fundamental"]["total"] if result["fundamental"]["total"] > 0 else 0.5
            
            # 計算趨勢與基本面的矛盾值 (Conflict)
            conflict_degree = abs(t_score - f_score)
            
            # 當量化指標嚴重衝突時（例如趨勢極多但估值極貴），調高預測引擎的判斷權重
            engine_weight = 0.30 + (0.25 * conflict_degree)  # 範圍限制在 30% ~ 55%
            quant_weight = 1.0 - engine_weight
            
            # 融合原始新聞情緒分與預測引擎的多方比例
            news_sentiment = 0.5
            if result.get("news"):
                bullish_count = sum(1 for n in result["news"] if any(w in n["title"] for w in ["漲", "紅", "追捧", "新高", "翻身"]))
                news_sentiment = 0.5 + (0.5 * (bullish_count / len(result["news"])))
            
            # 🚀 綜合評分基準點：40% 新聞情緒 + 60% 核心多因子多方比例
            ai_core_score = (news_sentiment * 0.4) + ((predict_bull_pct / 100.0) * 0.6)
            
            # 交叉加權計算最終綜合多空百分制得分
            quant_base = (t_score * 0.5 + f_score * 0.5) * quant_weight
            ai_base = ai_core_score * engine_weight
            final_composite_score = round((quant_base + ai_base) * 100, 1)
            
            # 判定狀態建議
            if final_composite_score >= 65:
                recommendation = "強勢看多 (多因子共振)" if conflict_degree < 0.4 else "多頭配置 (量化衝突由 AI 修正)"
            elif final_composite_score <= 45:
                recommendation = "保守觀望"
            else:
                recommendation = "多空交戰 (因子權重調整中)"
                
            result["adaptive_analysis"] = {
                "composite_score": final_composite_score,
                "ai_weight_pct": round(engine_weight * 100, 1),
                "quant_weight_pct": round(quant_weight * 100, 1),
                "conflict_degree": round(conflict_degree, 2),
                "predict_bull_pct": predict_bull_pct,
                "predicted_next_open": round(predict_open_val, 2) if predict_open_val else None,
                "recommendation": recommendation
            }
        else:
            result["adaptive_analysis"] = None

        results.append(result)
        time.sleep(0.1)  # 優化過場速度

    return jsonify({"ok": True, "results": results})


def _fetch_google_news(query: str, limit: int = 3) -> list:
    """從 Google News RSS 搜尋相關新聞。"""
    url = f"https://news.google.com/rss/search?q={requests.utils.quote(query)}+股票&hl=zh-TW&gl=TW&ceid=TW:zh-Hant"
    try:
        resp = requests.get(url, timeout=10)
        if not resp.ok:
            return []
        root = fromstring(resp.content)
        items = []
        for item in root.iter("item"):
            title = item.findtext("title", "")
            link = item.findtext("link", "")
            pub = item.findtext("pubDate", "")
            date_str = ""
            if pub:
                parts = pub.split()
                if len(parts) >= 4:
                    day, mon, year = parts[1], parts[2], parts[3]
                    months = {"Jan": "01", "Feb": "02", "Mar": "03", "Apr": "04",
                              "May": "05", "Jun": "06", "Jul": "07", "Aug": "08",
                              "Sep": "09", "Oct": "10", "Nov": "11", "Dec": "12"}
                    date_str = f"{year}-{months.get(mon, '01')}-{day.zfill(2)}"
            items.append({"title": title, "url": link, "date": date_str})
            if len(items) >= limit:
                break
        return items
    except Exception:
        return []