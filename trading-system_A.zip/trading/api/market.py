# -*- coding: utf-8 -*-
"""
trading/api/market.py — 大盤行情、新聞與即時個股路由中樞
專案路徑: D:\SourceCode\TypeScript\trading-system1\trading\api\market.py
"""
from flask import Blueprint, jsonify, request
from trading.api.auth import require_auth
from trading.services.container import container

market_bp = Blueprint("market", __name__)


@market_bp.route("/api/market")
@require_auth
def get_market():
    """獲取大盤快取數據"""
    cache = container.market_svc.get_data() if hasattr(container.market_svc, 'get_data') else {}
    return jsonify({"ok": True, "market": cache, "cached": bool(cache)})


@market_bp.route("/api/news")
@require_auth
def get_news():
    """獲取新聞聚合數據"""
    return jsonify({"ok": True, "news": container.news_agg.fetch()})


@market_bp.route("/api/news/analyze")
@require_auth
def analyze_news():
    """結合個股名稱進行量化情緒分析"""
    stock_map = container.scanner.get_stock_map()
    results   = container.news_agg.analyze_sentiment(stock_map)
    return jsonify({"ok": True, "results": results, "total": len(results)})


@market_bp.route("/api/market/quote")
@require_auth
def get_market_quote():
    """
    🟢 新增端點：獲取特定台股的即時當盤行情
    (對齊底層 MarketService 智慧三級防線與即時落盤機制)
    """
    stock_id = request.args.get("stock_id", "").strip()
    if not stock_id:
        return jsonify({"ok": False, "error": "缺少 stock_id 參數"}), 400
        
    try:
        quote = container.market_svc.get_current_quote(stock_id)
        return jsonify({"ok": True, "quote": quote})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 500