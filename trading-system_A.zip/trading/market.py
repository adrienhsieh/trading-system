# -*- coding: utf-8 -*-
"""
trading/market.py — 市場行情與多通道智慧備援服務 (融合強固完全體)
快取大盤與個股即時行情，內建 3 通道降級狀態機，TTL 自動刷新並安全落盤。
專案路徑: D:\SourceCode\TypeScript\trading-system1\trading\market.py
"""
import threading
import time
import sqlite3
import os
from datetime import datetime, time as datetime_time
import requests
import pandas as pd
from trading.constants import MARKET_CACHE_TTL
from trading.logger import get_logger

logger = get_logger("market")


class MarketService:
    """市場行情快取服務，支援 3 通道自動 Failover、時間感知與 SQL 自動落盤。"""

    TTL: int = MARKET_CACHE_TTL  # 快取有效秒數（預設 300 秒）

    # 基礎全球大盤標的
    SYMBOLS: dict = {
        "taiex":   "^TWII",
        "nasdaq":  "^IXIC",
        "sp500":   "^GSPC",
        "usd_twd": "TWD=X",
    }

    def __init__(self, config_manager=None):
        self.config_mgr = config_manager
        self.base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        self.db_path = os.path.join(self.base_dir, "trading_system.db")
        
        self._cache:      dict  = {}
        self._cache_time: float = 0.0
        self._lock                = threading.Lock()
        self._fetching            = threading.Event()  # set = 正在抓取中

        # ── 備援狀態機核心變數 ──────────────────────────────────
        self.current_channel: str = "TWSE"
        self.twse_failure_count: int = 0
        self.fail_counts = {"twse": 0, "finmind": 0} # 多通道降級計數器
        
        # 預設監控的台股核心觀察標的
        self.watch_stocks = ["2330", "2317", "2454"] 

    # ── 智慧時間感知狀態機 ─────────────────────────────────────

    def get_market_status(self) -> str:
        """精算當前時間狀態，防止非盤中時間無效請求"""
        now = datetime.now()
        if now.weekday() >= 5: 
            return "WEEKEND"
        
        current_time = now.time()
        if datetime_time(8, 30) <= current_time <= datetime_time(13, 35):
            return "TRADING_HOURS"
        elif datetime_time(13, 35) < current_time <= datetime_time(15, 0):
            return "POST_MARKET"
        return "OFF_HOURS"

    # ── 公開介面 ───────────────────────────────────────────────

    def get_data(self) -> dict:
        """取得市場快取；若過期且未在刷新中，則觸發背景刷新。"""
        if time.time() - self._cache_time > self.TTL and not self._fetching.is_set():
            if not self._fetching.is_set():
                self._fetching.set()
                threading.Thread(target=self._fetch, daemon=True).start()
        with self._lock:
            return dict(self._cache)

    def refresh(self) -> None:
        """強制觸發同步刷新（阻塞直到完成）。"""
        self._fetch()

    def get_current_quote(self, stock_id: str) -> dict:
        """
        🟢 精準外部串接：獲取特定台股即時行情 
        (具備三級 Failover 降級防護網、智慧 ETF 字尾識別與安全落盤)
        """
        stock_id = str(stock_id).strip()
        status = self.get_market_status()
        
        # 非交易時段自動收攏通道，並重置失敗計數器防止虛耗
        if status != "TRADING_HOURS" and self.current_channel != "TWSE":
            logger.info("🌙 非交易時段，個股行情通道回歸官方 TWSE 基準。")
            self.current_channel = "TWSE"
            self.fail_counts = {"twse": 0, "finmind": 0}

        # 🚀 建立 ETF 友善字尾 (避免 0050.TWO 這種錯誤)
        if stock_id.startswith('00'):
            formatted_sym = f"{stock_id}.TW"
        elif stock_id.isdigit() and int(stock_id) >= 5000:
            formatted_sym = f"{stock_id}.TWO"
        else:
            formatted_sym = f"{stock_id}.TW"

        # ── 第一級防線：TWSE 官方 API ──
        if self.current_channel == "TWSE":
            try:
                url = f"https://mis.twse.com.tw/stock/api/getStockInfo.jsp?ex_ch=tse_{stock_id}.tw|otc_{stock_id}.tw"
                resp = requests.get(url, timeout=5)
                if resp.status_code == 200:
                    data = resp.json() or {}
                    info = data.get("msgArray", [])
                    if info:
                        i = info[0]
                        close_val = float(i.get("z", i.get("y", 0.0)))
                        quote = {
                            "close": close_val, "open": float(i.get("o", close_val)),
                            "high": float(i.get("h", close_val)), "low": float(i.get("l", close_val)),
                            "volume": int(i.get("v", 0)) * 1000, "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                        }
                        self.fail_counts["twse"] = 0
                        self._save_quote_to_db(stock_id, quote["close"], quote["volume"], "TWSE_Official")
                        return quote
            except Exception as e:
                logger.warning(f"⚠️ TWSE 通道請求異常 ({stock_id}): {e}")
            
            self.fail_counts["twse"] += 1
            if self.fail_counts["twse"] >= 3 and status == "TRADING_HOURS":
                logger.error("🚨 TWSE 官方通道連續失敗，降級至 FinMind！")
                self.current_channel = "FinMind"

        # ── 第二級防線：FinMind ──
        if self.current_channel == "FinMind":
            try:
                token = self.config_mgr.load().get("finmind_token", "") if self.config_mgr else ""
                url = "https://api.finmindtrade.com/api/v4/data"
                params = {"dataset": "TaiwanStockPriceTick", "data_id": stock_id, "date": datetime.now().strftime("%Y-%m-%d"), "token": token}
                resp = requests.get(url, params=params, timeout=5)
                if resp.status_code == 200:
                    res_data = resp.json() or {}
                    data_list = res_data.get("data", [])
                    if data_list:
                        df = pd.DataFrame(data_list)
                        quote = {
                            "close": float(df["price"].iloc[-1]), "open": float(df["price"].iloc[0]),
                            "high": float(df["price"].max()), "low": float(df["price"].min()),
                            "volume": int(df["volume"].sum()), "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                        }
                        self.fail_counts["finmind"] = 0
                        self._save_quote_to_db(stock_id, quote["close"], quote["volume"], "FinMind_API")
                        return quote
            except Exception as e:
                logger.warning(f"⚠️ FinMind 通道請求異常 ({stock_id}): {e}")
                
            self.fail_counts["finmind"] += 1
            if self.fail_counts["finmind"] >= 3 and status == "TRADING_HOURS":
                logger.error("🚨 FinMind 通道失效，降級至 YFinance 境外通道！")
                self.current_channel = "YFinance"

        # ── 第三級防線：YFinance 境外保底 ──
        try:
            import yfinance as yf
            ticker = yf.Ticker(formatted_sym)
            tod = ticker.history(period="1d")
            if not tod.empty:
                last_row = tod.iloc[-1]
                quote = {
                    "close": float(last_row["Close"]), "open": float(last_row["Open"]),
                    "high": float(last_row["High"]), "low": float(last_row["Low"]),
                    "volume": int(last_row["Volume"]), "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                }
                self._save_quote_to_db(stock_id, quote["close"], quote["volume"], "YFinance_Fallback")
                return quote
        except Exception as e:
            logger.error(f"❌ 三級防線全數崩潰 ({stock_id}): {e}")
            
        return self._get_last_cached_quote(stock_id)

    def get_history(self, stock_id: str, days: int = 60) -> pd.DataFrame:
        """獲取歷史 K 線數據 (供預測與指標計算使用)"""
        stock_id = str(stock_id).strip()
        if stock_id.startswith('00'):
            formatted_sym = f"{stock_id}.TW"
        elif stock_id.isdigit() and int(stock_id) >= 5000:
            formatted_sym = f"{stock_id}.TWO"
        else:
            formatted_sym = f"{stock_id}.TW"
            
        try:
            import yfinance as yf
            df = yf.download(formatted_sym, period=f"{days}d", progress=False)
            if not df.empty:
                if isinstance(df.columns, pd.MultiIndex):
                    df.columns = df.columns.get_level_values(0)
                df.columns = [str(c).capitalize() for c in df.columns]
                return df
        except Exception as e:
            logger.error(f"獲取 {stock_id} 歷史 K 線失敗: {e}")
        return pd.DataFrame()

    # ── 內部抓取與多通道調度 ───────────────────────────────────

    def _fetch(self) -> None:
        """抓取全球大盤資料、驅動台股個股 3 通道備援，並自動 SQL 落盤"""
        import concurrent.futures
        import yfinance as yf

        status = self.get_market_status()
        
        # 1. 時間防禦：非交易時間自動收攏通道
        if status != "TRADING_HOURS" and self.current_channel != "TWSE":
            self.current_channel = "TWSE"
            self.twse_failure_count = 0
            logger.info("非盤中交易時間，自動重置多通道狀態為 [TWSE]")

        result: dict = {}

        # ── (A) 抓取全球大盤與匯率快取 ──
        def _sym(key: str, sym: str):
            try:
                df = yf.Ticker(sym).history(period="5d", interval="1d")
                if len(df) >= 2:
                    curr = float(df["Close"].iloc[-1])
                    prev = float(df["Close"].iloc[-2])
                    return key, {"price": round(curr, 2), "change_pct": round((curr - prev) / prev * 100, 2)}
            except Exception:
                pass
            return key, {"price": None, "change_pct": None}

        def _ema() -> dict:
            try:
                df = yf.Ticker("^TWII").history(period="3mo", interval="1d")
                if not df.empty and len(df) >= 20:
                    c = df["Close"]
                    e = c.ewm(span=20, adjust=False).mean()
                    return {
                        "market_above_ema20": bool(float(c.iloc[-1]) > float(e.iloc[-1])),
                        "ema20_tw":           round(float(e.iloc[-1]), 0),
                    }
            except Exception:
                pass
            return {"market_above_ema20": None, "ema20_tw": None}

        try:
            with concurrent.futures.ThreadPoolExecutor(max_workers=5) as ex:
                futs  = {ex.submit(_sym, k, v): k for k, v in self.SYMBOLS.items()}
                ema_f = ex.submit(_ema)
                for f in concurrent.futures.as_completed(futs, timeout=20):
                    try:
                        k, d = f.result()
                        result[k] = d
                    except Exception:
                        pass
                try:
                    result.update(ema_f.result(timeout=10))
                except Exception:
                    result["market_above_ema20"] = None
        except Exception as e:
            logger.error(f"大盤基礎行情並行抓取異常: {e}")

        # ── (B) 台股個股智慧調度 ──
        stock_quotes = {}
        for code in self.watch_stocks:
            try:
                q = self.get_current_quote(code)
                if q and q.get("close", 0.0) > 0:
                    stock_quotes[code] = {"price": q["close"], "volume": q["volume"], "source": self.current_channel}
            except Exception:
                pass
        result["stocks"] = stock_quotes

        # ── (C) 快取寫入與釋放鎖 ──
        if result:
            with self._lock:
                self._cache      = result
                self._cache_time = time.time()
            logger.info(f"行情快取同步刷新完成。當前活動通道: [{self.current_channel}]")

        self._fetching.clear()

    # ── 安全本土地落盤快取實作 ──────────────────────────────────

    def _save_quote_to_db(self, stock_code: str, price: float, volume: int, source: str):
        """取代原本會噴錯的外部函數，安全內建落盤機制"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS market_quotes_cache (
                        stock_id TEXT PRIMARY KEY, close REAL, open REAL, high REAL, low REAL,
                        volume INTEGER, update_time TEXT, source TEXT
                    )
                """)
                now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                cursor.execute("""
                    INSERT INTO market_quotes_cache (stock_id, close, open, high, low, volume, update_time, source)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    ON CONFLICT(stock_id) DO UPDATE SET
                        close=excluded.close, volume=excluded.volume, update_time=excluded.update_time, source=excluded.source
                """, (stock_code, price, price, price, price, volume, now_str, source))
                conn.commit()
        except Exception as e:
            logger.error(f"本地 SQLite 快取落盤失敗: {e}")

    def _get_last_cached_quote(self, stock_id: str) -> dict:
        """當網絡全部斷線時，提取最後一次歷史快取兜底"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                conn.row_factory = sqlite3.Row
                cursor = conn.cursor()
                cursor.execute("SELECT close, volume, update_time FROM market_quotes_cache WHERE stock_id = ?", (stock_id,))
                row = cursor.fetchone()
                if row:
                    r = dict(row)
                    return {"close": r["close"], "open": r["close"], "high": r["close"], "low": r["close"], "volume": r["volume"], "time": r["update_time"]}
        except Exception:
            pass
        return {"close": 0.0, "open": 0.0, "high": 0.0, "low": 0.0, "volume": 0, "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S")}