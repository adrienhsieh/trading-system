# -*- coding: utf-8 -*-
"""
trading/services/config_db.py — 交易系統資料庫實時管理與配置中樞
提供使用者前端模組配置 ORM、內建 SQL 編輯器，以及市場即時行情落盤接口。
專案路徑: D:\SourceCode\TypeScript\trading-system1\trading\services\config_db.py
"""
import os
import json
from datetime import datetime
from pathlib import Path
from sqlalchemy import create_engine, Column, String, Float, Integer, JSON, text, inspect
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker

# 確保路徑指向正確的專案根目錄
BASE_DIR = Path(__file__).parent.parent.parent
DATABASE_URL = f"sqlite:///{BASE_DIR}/trading_system.db"

engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

# ==============================================================================
# 1. 資料庫資料表定義
# ==============================================================================
class UserPageConfig(Base):
    __tablename__ = "user_page_configs"
    
    user_id = Column(String, primary_key=True, index=True)
    module_id = Column(String, primary_key=True, index=True)
    configs = Column(JSON, nullable=False)


class MarketQuoteCache(Base):
    """🟢 補上行情落盤快取資料表，對接多通道降級防護網"""
    __tablename__ = "market_quotes_cache"
    
    stock_id = Column(String, primary_key=True, index=True)
    close = Column(Float, nullable=False)
    open = Column(Float)
    high = Column(Float)
    low = Column(Float)
    volume = Column(Integer)
    update_time = Column(String, nullable=False)
    source = Column(String)


def init_db():
    """初始化資料庫（自動建表）"""
    Base.metadata.create_all(bind=engine)


# 系統預設設定值
DEFAULT_MODULE_CONFIGS = {
    "grid_trading": {
        "grid_num": 10,
        "lower_limit": 0,
        "auto_stop": False
    },
    "kline_chart": {
        "theme": "dark",
        "ma_line": [5, 10, 20, 60]
    },
    "settings_page": {
        "total_capital": 3000000,
        "consecutive_losses": 0
    }
}

# ==============================================================================
# 2. 🚀 策略端核心功能：讀取與寫入設定 / 行情落盤
# ==============================================================================
def get_strategy_config(user_id: str, module_id: str) -> dict:
    """供 trading/ 內部策略腳本直接呼叫獲取使用者自訂參數。"""
    db = SessionLocal()
    try:
        record = db.query(UserPageConfig).filter(
            UserPageConfig.user_id == user_id,
            UserPageConfig.module_id == module_id
        ).first()
        if record:
            return record.configs
        return DEFAULT_MODULE_CONFIGS.get(module_id, {})
    finally:
        db.close()


def save_market_quote(stock_code: str, price: float, volume: int, source: str) -> None:
    """
    🟢 核心修復：補全原本缺少的即時行情落盤接口，徹底解決全案的 ImportError。
    使用 SQLAlchemy ORM Upsert 語法自動更新本地 SQLite 數據。
    """
    db = SessionLocal()
    try:
        now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        record = db.query(MarketQuoteCache).filter(MarketQuoteCache.stock_id == str(stock_code)).first()
        
        if record:
            record.close = float(price)
            record.volume = int(volume)
            record.update_time = now_str
            record.source = str(source)
        else:
            new_quote = MarketQuoteCache(
                stock_id=str(stock_code),
                close=float(price),
                open=float(price),
                high=float(price),
                low=float(price),
                volume=int(volume),
                update_time=now_str,
                source=str(source)
            )
            db.add(new_quote)
        db.commit()
    except Exception as e:
        db.rollback()
        # 這裡不抛出異常，僅做日誌相容防禦，避免網絡或本地磁碟 IO 鎖定摧毀主服務
        print(f"⚠️ [config_db] 寫入本地即時行情快取失敗: {e}")
    finally:
        db.close()

# ==============================================================================
# 3. 🛠️ 資料表管理工具 與 🖥️ SQL 編輯器 (主控台模式)
# ==============================================================================
class DatabaseManager:
    @staticmethod
    def show_all_tables():
        """列出資料庫內所有的資料表與其結構"""
        inspector = inspect(engine)
        tables = inspector.get_table_names()
        print(f"\n📁 [資料表總覽] 目前 SQLite 內共有 {len(tables)} 個資料表：")
        print("-" * 60)
        for table_name in tables:
            print(f" 🔹 資料表名稱: 【 {table_name} 】")
            columns = inspector.get_columns(table_name)
            col_details = [f"{col['name']} ({col['type']})" for col in columns]
            print(f"    ↳ 欄位結構: {', '.join(col_details)}")
        print("-" * 60)

    @staticmethod
    def execute_sql(sql_query: str):
        """🖥️ 內建 SQL 編輯器：執行任意 SQL 語句並格式化輸出結果"""
        print(f"\n⚡ [SQL EDITOR] 執行指令: {sql_query}")
        print("=" * 60)
        db = SessionLocal()
        try:
            result = db.execute(text(sql_query))
            
            if result.returns_rows:
                rows = result.all()
                if not rows:
                    print(" ( 查詢成功，但資料表中目前沒有任何資料 )")
                else:
                    headers = list(result.keys())
                    print(f" | {' | '.join(headers)} |")
                    print(" | " + " | ".join(["-" * len(h) for h in headers]) + " |")
                    for row in rows:
                        row_strs = [json.dumps(val) if isinstance(val, (dict, list)) else str(val) for val in row]
                        print(f" | {' | '.join(row_strs)} |")
                print(f" 💡 總共回傳了 {len(rows)} 筆資料。")
            else:
                db.commit()
                print(f" ✅ 執行成功！受影響的資料列列數: {result.rowcount}")
        except Exception as e:
            db.rollback()
            print(f" ❌ [SQL 錯誤]: {str(e)}")
        finally:
            db.close()
        print("=" * 60)

# ==============================================================================
# 當此檔案被直接執行時啟動管理面板
# ==============================================================================
if __name__ == "__main__":
    init_db()
    print("\n==================================================")
    print("      ⚔️ 交易系統資料庫實時管理與 SQL 戰情面板 ⚔️")
    print("==================================================")
    
    DatabaseManager.show_all_tables()
    
    print("🔍 [策略測試] 模擬核心策略讀取目前使用者 'jack' 的 'grid_trading' 設定...")
    jack_cfg = get_strategy_config("jack", "grid_trading")
    print(f" 👉 讀取成功！當前網格數量為: {jack_cfg.get('grid_num')} 格，下限價格: {jack_cfg.get('lower_limit')}")
    print("-" * 60)

    # 查詢測試
    DatabaseManager.execute_sql("SELECT user_id, module_id, configs FROM user_page_configs;")