# -*- coding: utf-8 -*-
# trading/services/__init__.py

from trading.services.container import container

__all__ = ["container"]