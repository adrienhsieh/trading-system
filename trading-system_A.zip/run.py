import sys
from trading.scanner import StockScanner
from trading.logger import get_logger

logger = get_logger("main")

def run_scan_for_list(scanner: StockScanner, target_stocks: list, capital: float, risk_pct: float, strategy: str):
    """【前版核心機制】針對傳入的特定股票清單執行局部掃描與分析"""
    logger.info("🎯 執行指定個股掃描，目標清單: %s", target_stocks)
    
    # 執行掃描
    results = scanner.run_scan(
        candidates=target_stocks,
        capital=capital,
        risk_pct=risk_pct,
        strategy=strategy
    )
    
    # 格式化並輸出
    api_output = scanner.format_for_api(results, strategy=strategy)
    return api_output

def main():
    logger.info("🚀 啟動台股技術面掃描系統 (自訂清單/全市場前版機制)...")
    
    try:
        # 1. 初始化掃描器
        scanner = StockScanner()
        
        # 2. 設定執行參數
        capital = 1000000.0  # 本金 100 萬
        risk_pct = 2.0       # 每筆交易 2% 風險
        strategy = "trend"   # 策略：trend / ict
        
        # ── 💡 模式切換 ──
        # 模式 A：如果你只想局部測試幾檔，解除下方的註解：
        # test_list = ["2330", "2317", "2454", "2308"]
        
        # 模式 B：預設維持下載全市場清單
        logger.info("🔍 正在下載 TWSE/TPEX 全市場股票清單...")
        test_list = scanner.get_all_tw_stocks()
        
        total_count = len(test_list)
        if total_count == 0:
            logger.error("❌ 無法取得股票清單，請檢查網路連線。")
            return
            
        logger.info("📊 成功載入目標清單，共計 %d 檔個股，準備分析...", total_count)
        
        # 3. 呼叫局部清單掃描函式
        api_output = run_scan_for_list(
            scanner=scanner,
            target_stocks=test_list,
            capital=capital,
            risk_pct=risk_pct,
            strategy=strategy
        )
        
        logger.info("✅ 掃描完畢！符合策略條件的股票共計 %d 檔", len(api_output))
        
        # 4. 列印前 10 名成果
        print("\n" + "="*65)
        print(f" 🏆 台股技術面掃描排行 TOP 10 (策略: {strategy.upper()})")
        print("="*65)
        for i, item in enumerate(api_output[:10], 1):
            print(f"[{i:02d}] {item['code']} {item['name']} | 綜合評分: {item['score']} | 收盤價: {item['close']}")
            print(f"     👉 進場: {item['entry']} | 停損: {item['stop']} | 目標: {item['target']} | 推薦股數: {item['shares']} 股")
            print("-" * 65)
            
    except KeyboardInterrupt:
        logger.warning("\n🛑 使用者中止執行。")
        sys.exit(0)
    except Exception as e:
        logger.critical("💥 系統執行發生嚴重錯誤: %s", e, exc_info=True)

if __name__ == "__main__":
    main()